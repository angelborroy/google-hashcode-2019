package es.keensoft.bean;

import java.util.HashSet;

public interface Taggable {

	public HashSet<String> getTags();

}
